from __future__ import annotations

from app.ui.main import main

__all__ = ["main"]
